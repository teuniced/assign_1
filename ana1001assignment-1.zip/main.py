#ANA1001_Assignment_1 
#Toluwalope Eunice David

print ("QUESTION 1 - Describing Programs to create".center(75,"~"))
#QUESTION 1 - Describing Programs to create
#Program 1: I would like to create a program that lets lactose-intolerant humans attack the milky way galaxy.
#Program 2: I would like to create a program that lets lactose-intolerant humans attack the milky way galaxy.
#Program 3: I would like to create a program that lets lactose-intolerant humans attack the milky way galaxy.
#Program 4: I would like to create a program that lets lactose-intolerant humans attack the milky way galaxy.


print ("QUESTION 2 - Formatting City Names".center(75,"~"))
#QUESTION 2 - Formatting City Names
city_name = "pickering"
print(city_name)

city_name = "abuja"
print(city_name)
     #Formatting output
print(city_name.title())
print(city_name.upper())


city_name = "bordeaux"
print(city_name)
     #Formatting output
print(city_name.title())
print(city_name.upper())


print ("QUESTION 3".center(75,"~"))
#QUESTION 3
my_name = "eunice"
print(f"Welcome {my_name}, redeem your $30 coupon!") #prints 'my_name' output using the 'f' string
#Modifying my_name output case
print(f"Welcome {my_name.lower()}, redeem your $30 coupon!")
print(f"Welcome {my_name.title()}, redeem your $30 coupon!")
print(f"Welcome {my_name.upper()}, redeem your $30 coupon!")


print ("QUESTION 4".center(75,"~"))
#QUESTION 4 
cad_food = "Pouding Chômeur"
print (f"\n\t\t\t {cad_food}\t") # printing with whitespace characters like \t,\n\r
#Using stripping functions to remove confusing extra whitespaces
print (f"{cad_food.lstrip()}")
print (f"{cad_food.rstrip()}")
print (f"{cad_food.strip()}")

print ("Question 4 edit")
cad_food= (f"\n\t\t\t {cad_food}\t\t") # printing with whitespace characters like \t,\n\r
#Using stripping functions to remove confusing extra whitespaces
print (f"{cad_food.lstrip()}")
print (f"{cad_food.rstrip()}")
print (f"{cad_food.strip()}")





print ("QUESTION 5 - Maths Operations".center(75,"~")) #"fancyheader"
#QUESTION 5 - Maths Operations
add_2022 ,sub_2022,div_2022, mult_2022 = 1998 + 24, 2032 - 10, int(20220 / 10), int(202.2 * 10) #used int to remove unncessary decimals
print (add_2022, sub_2022, div_2022, mult_2022) # just a check to see if multiple assignments on previous line worked
print (f"Adding 1998 plus 24 equals {add_2022}", f" \nSubtracting 10 from 2032 equals {sub_2022}" ) #printed message explaining results using f string.
print ("Dividing 20220 by 10 equals " + str(div_2022)) #printed message explaining math operation results using join i.e. "+". repeat for next line.
print ("Multiplying 202.2 times 10 equals " + str(mult_2022))


print ("QUESTION 6 - Solution to dog's speed".center(75,"~")) 
#distance_park is distance covered across park 
#travel_time is time taken to cross park
#dog_speed = distance_park/travel_time
distance_park = 80.0 
travel_time   = 16.0
dog_speed     = distance_park/travel_time
print (f"The speed of the dog is {dog_speed} meters per second.") #Prints dog_speed using f string


